<form method="get" id="searchform" class="submit-search-form" action="<?php echo home_url()  ?>/">
    <div id="s"><input type="text" name="s" class="search-input" onfocus="if(value==defaultValue)value=''" onblur="if(value=='')value=defaultValue" value=""/></div>
    <div class="searchform-right left"><input type="submit" id="searchsubmit" class="submit-button" value="" /></div>
</form>