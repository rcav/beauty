jQuery(function() {
    "use strict";
    jQuery('.flexslider').flexslider({
           pauseOnHover:true,
           slideshow: true,
           useCSS: false
    });
});